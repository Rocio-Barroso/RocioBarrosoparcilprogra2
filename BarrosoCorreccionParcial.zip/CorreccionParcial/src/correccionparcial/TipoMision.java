
package correccionparcial;


public enum TipoMision {
    CARTOGRAFIA,                                                                     
    INVESTIGACIO,                                  
    CONTACTO;
    
    @Override
    public String toString(){
        String aux = name().toLowerCase();
        return aux.substring(0, 1).toUpperCase() + aux.substring(1);
    }
}
    