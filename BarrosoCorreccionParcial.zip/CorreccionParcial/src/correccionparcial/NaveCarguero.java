
package correccionparcial;


public class NaveCarguero extends NaveEspacial implements Explorable, Mantenible{
    private static final int CAPACIDAD_MAX = 100;
    private static final int CAPACIDAD_MIN = 500;
    private int capacidadCarga;

    public NaveCarguero(String nombre, int capacidadTripulacion, int anioLanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadCarga = capacidadCarga;
    }
    
    private void validarcapacidad(int capacidad){
        if(capacidad < CAPACIDAD_MIN || capacidad > CAPACIDAD_MAX){
            throw new IllegalArgumentException("capacidad insuficiente");
    }
    
}

    @Override
    public void explorar() {
      System.out.println("Nave : %s explorando".formatted(getNombre()));    
    }

    @Override
    public void RealizarMantenimiento() {
    System.out.println("carguero : %s reaizando mantenimiento".formatted(getNombre()));    
    }

    @Override
    public String toString() {
        return "NaveCarguero{" + super.toString() + "capacidadCarga=" + capacidadCarga + '}';
    }
    
    
}
