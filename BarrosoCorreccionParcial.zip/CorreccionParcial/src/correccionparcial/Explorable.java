
package correccionparcial;


public interface Explorable {
    void explorar();
}
