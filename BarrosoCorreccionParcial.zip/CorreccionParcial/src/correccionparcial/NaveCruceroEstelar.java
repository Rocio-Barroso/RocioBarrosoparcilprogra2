
package correccionparcial;


public class NaveCruceroEstelar extends NaveEspacial implements Mantenible {
    private final int pasajeros;

    public NaveCruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento, int pasajeros) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.pasajeros = pasajeros;
    }
    
    @Override
    public String toString() {
        return "NaveCruceroEstelar{" + super.toString() + "pasajeros=" + pasajeros + '}';
    }

    @Override
    public void RealizarMantenimiento() {
        System.out.println("crucero : %s reaizando mantenimiento".formatted(getNombre()));
    }
    
     
}
