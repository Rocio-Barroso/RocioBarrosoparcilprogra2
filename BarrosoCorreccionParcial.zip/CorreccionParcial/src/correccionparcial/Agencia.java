
package correccionparcial;

import java.util.ArrayList;
import java.util.List;


public class Agencia {
    private List<NaveEspacial> naves = new ArrayList<>();
    
    
    public void agregarNave(NaveEspacial nave){
        validarNave(nave);
        naves.add(nave);
    }
    
    private void validarNave(NaveEspacial nave){
        if (nave == null){
            throw new NullPointerException("nave nula"); 
        }
        if (naves.contains(nave)){
            throw new YaExisteNaveException();
        }
    }
    
    public void mostrarNave(){
        if(naves.isEmpty()){
            System.out.println("no hay naves");
            return;
        }
        System.out.println("listado de naves");
        for(NaveEspacial nave : naves){
            System.out.println(nave);
        }
    }
    
    public void iniciarExploracion(){
        System.out.println("Iniciando Exploracion");
        for(NaveEspacial nave : naves){
            if(nave instanceof Explorable e){
                e.explorar();
            }
            else{
                System.out.println(nave + "no puede explorar");
            }
        }
    }
    
    public void RealizarMantenimuento(){
        System.out.println("Realizando Mantenimiento");
        for(NaveEspacial nave : naves){
            if(nave instanceof Mantenible m){
                m.RealizarMantenimiento();
            }
            else{
                System.out.println(nave + "no puede realizar mantenimiento");
            }
        }
    }
    
    public List<NaveEspacial> filtrarNaveTipoMision(TipoMision tipo){
        List<NaveEspacial> toReturn = new ArrayList<>();
        for(NaveEspacial nave : naves){
            if(nave instanceof NaveExploracion n && n.esTipoMision(tipo)){
                toReturn.add(nave);
            }
        }
        return toReturn;
    }

}