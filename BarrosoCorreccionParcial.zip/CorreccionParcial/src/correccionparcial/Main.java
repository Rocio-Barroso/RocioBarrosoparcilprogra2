
package correccionparcial;

import java.util.Iterator;


public class Main {

    public static void main(String[] args) {
        Agencia agencia = new Agencia();
        harcodearAgencia(agencia);
        
        agencia.mostrarNave();
        
        System.out.println("---------------------------------");

        agencia.iniciarExploracion();
        
        System.out.println("---------------------------------");
        
        agencia.RealizarMantenimuento();
        
        System.out.println("---------------------------------");
        
        Iterator<NaveEspacial> it = agencia.filtrarNaveTipoMision(TipoMision.CONTACTO).iterator();
        
        while(it.hasNext())
            System.out.println(it.hasNext());
    }
    public static void harcodearAgencia(Agencia a){
        a.agregarNave(new NaveExploracion(TipoMision.CARTOGRAFIA, "Explora A", 100, 2323));
        a.agregarNave(new NaveExploracion(TipoMision.CARTOGRAFIA, "Explora B", 100, 2323));
        a.agregarNave(new NaveExploracion(TipoMision.CARTOGRAFIA, "Explora C", 100, 2323));
        
        a.agregarNave(new NaveCarguero("Carguero A", 100, 2323, 2050));
        a.agregarNave(new NaveCarguero("Carguero B", 100, 2323, 3000));
        a.agregarNave(new NaveCarguero("Carguero C", 200, 2323, 300));
        
        a.agregarNave(new NaveCruceroEstelar("Crucero A", 200, 2040, 1000));
        a.agregarNave(new NaveCruceroEstelar("Crucero B", 300, 2045, 10000));
        a.agregarNave(new NaveCruceroEstelar("Crucero C", 400, 2050, 100000));
   
    }
}
