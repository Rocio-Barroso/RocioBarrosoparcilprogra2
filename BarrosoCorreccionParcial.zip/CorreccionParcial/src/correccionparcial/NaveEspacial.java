
package correccionparcial;

import java.util.Objects;


public class NaveEspacial {
    private String nombre;
    private int capacidadTripulacion;
    private int anioLanzamiento;

    public NaveEspacial(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
    @Override
    public int hashCode(){
        return Objects.hash(nombre, anioLanzamiento);
    }

    public String getNombre() {
        return nombre;
    }
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof NaveEspacial n)){
            return false;
        }
        return nombre.equals(n.nombre) && anioLanzamiento == n.anioLanzamiento;
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + '}';
    }
  }

 

