
package correccionparcial;


public class NaveExploracion extends NaveEspacial implements Explorable{
    
    private final TipoMision tipo; 

    public NaveExploracion(TipoMision tipo, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipo = tipo;
    }

    public boolean esTipoMision(TipoMision tipo){
        return this.tipo == tipo; 
    }
    
    @Override
    public void explorar() {
        System.out.println("Nave : %s explorando".formatted(getNombre()));
    }

    @Override
    public String toString() {
        return "NaveExploracion{" + super.toString() + "tipo=" + tipo + '}';
    }

}
  