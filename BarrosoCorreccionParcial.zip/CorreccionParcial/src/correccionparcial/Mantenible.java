
package correccionparcial;


public interface Mantenible {
    void RealizarMantenimiento();
}
