
package correccionparcial;


public class YaExisteNaveException extends RuntimeException{

    private static final String MESSAGE = "Ya existe una nave con ese nombre.";

    public YaExisteNaveException() { //este invoca alde abajo y le pasa mssage por defecto
        this(MESSAGE);
    }

    public YaExisteNaveException(String mensaje) { // este recibe un mensaje por parametro con el constrictor del pabdre
        super(mensaje);
    }
}
    
