
package parcialnavesespaciales;


public class NaveDeExploracion extends Nave implements Explorable{
    private int pesoMaximoSoportado;
    private TipoDeMision tipoMision;
    
    public NaveDeExploracion(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento, TipoDeMision tipoMision, int pesoMaximoSoportado) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.pesoMaximoSoportado = pesoMaximoSoportado;
        this.tipoMision = tipoMision;
    }
    
    public TipoDeMision getTipoMision(){
        return tipoMision;
    }
    
    @Override
    public void explorar(){
        System.out.println("Explorando mision : " + tipoMision);
    }
    
    @Override
    public String getDescripcion() {
        return "Nave de Exploración: " + getNombre() + " (" + tipoMision + ")";
    }
}
