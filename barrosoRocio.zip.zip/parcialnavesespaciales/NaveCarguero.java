
package parcialnavesespaciales;


public class NaveCarguero extends Nave implements Explorable, Mantenible{
    private static final int MIN_CARGA_TONELADAS = 100;
    private static final int MAX_CARGA_TONELADAS = 500;
    private int cargaActual;

    public NaveCarguero(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.cargaActual = cargaActual;
    }
    
    @Override
    public void explorar() {
        System.out.println("Nave carguero en misión.");
    }

    @Override
    public void realizarMantenimiento() {
        System.out.println("Mantenimiento a carguero realizado  " + getNombre());
    }

    @Override
    public String getDescripcion() {
        return super.toString() + ", Carga: " + cargaActual + " toneladas";
    }
}
