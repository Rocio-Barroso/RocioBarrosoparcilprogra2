
package parcialnavesespaciales;

import java.util.Objects;


public abstract class Nave {
    private String nombre;
    private int CapacidadTripulacion;
    private int anioDeLanzamiento;
    private TipoDeMision tipoDeMision;
    
    public Nave(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento){
        this.nombre = nombre;
        this.CapacidadTripulacion = capacidadDeTripulacion;
        this.anioDeLanzamiento = anioDeLanzamiento;    
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidadTripulacion() {
        return CapacidadTripulacion;
    }

    public int getAnioDeLanzamiento() {
        return anioDeLanzamiento;
    }
    
    public TipoDeMision getTipoDeMision(){
        return tipoDeMision;
    }
    
    public abstract String getDescripcion();
    
@Override
    public int hashCode() {
        return Objects.hash(nombre);
    }   

@Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Nave n)){
            return false;
        }
        return this.nombre.equals(n.nombre);
    }

    @Override
    public String toString() {
        return getDescripcion();
    }
    
    
    
}
