/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialnavesespaciales;

import java.util.ArrayList;
import java.util.List;


public class AgenciaEspacial {
    private List<Nave> naves;

    public AgenciaEspacial() {
        this.naves = new ArrayList<>();
    }

    public void agregarNave(Nave nave) throws YaExisteNaveException {
        if (naves.contains(nave)) {
            throw new YaExisteNaveException("Ya existe una nave con ese nombre y año.");
        }
        naves.add(nave);
    }

    public void mostrarNaves() {
        for (Nave n : naves) {
            System.out.println(n.getDescripcion());
        }
    }

    public void iniciarExploracion() {
        for (Nave n : naves) {
            if (n instanceof Explorable explorable) {
                explorable.explorar();
            } else {
                System.out.println("La nave " + n.getNombre() + " no puede explorar.");
            }
        }
    }

    public void filtrarPorTipoMision(TipoDeMision tipo) {
        for (Nave n : naves) {
            if (n instanceof NaveDeExploracion exploracion && exploracion.getTipoMision() == tipo) {
                System.out.println(exploracion.getDescripcion());
            }
        }
    }
}

