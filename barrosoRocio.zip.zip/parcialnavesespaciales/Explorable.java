
package parcialnavesespaciales;


public interface Explorable {
    public void explorar();
}
