
package parcialnavesespaciales;

public enum TipoDeMision {
    CARTOGRAFÍA,
    INVESTIGACIÓN,
    CONTACTO 
}
