/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialnavesespaciales;

/**
 *
 * @author rocio
 */
public class CruceroEstelar extends Nave implements Mantenible {
    private int pesoMaximoSoportado;
    private int cantidadPasajeros;

    public CruceroEstelar(int pesoMaximoSoportado, int cantidadPasajeros, String nombre, int capacidadDeTripulacion, int anioDeLanzamiento) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.pesoMaximoSoportado = pesoMaximoSoportado;
        this.cantidadPasajeros = cantidadPasajeros;
    }
    
    @Override
    public void realizarMantenimiento(){
        System.out.println("mantenimiento realizado ; "); 
    }
    
    @Override
    public String getDescripcion() {
        return super.toString() + ", Pasajeros: " + cantidadPasajeros + ", Peso Máx: " + pesoMaximoSoportado;
    }
 
    
    }
    
   

