
package parcialnavesespaciales;


public interface Mantenible {
    public void realizarMantenimiento();
}
